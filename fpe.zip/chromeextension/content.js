(async function() {
    const hostname = window.location.hostname;
    
    function injectScript() {
        if (document.getElementById('force-unblock-script')) return;
        const script = document.createElement('script');
        script.id = 'force-unblock-script';
        script.src = chrome.runtime.getURL('injected.js');
        script.documentElement = true;
        (document.head || document.documentElement).appendChild(script);
        // script.onload = () => script.remove(); // Keep it if we need to send events? 
        // Actually script execution happens even if we remove it.
    }

    async function sendConfig() {
        const result = await chrome.storage.local.get(['enabled_sites', 'always_active_sites', 'global_mode']);
        const isGlobal = !!result.global_mode;
        
        const config = {
            unblockEnabled: isGlobal || !!(result.enabled_sites && result.enabled_sites[hostname]),
            alwaysActiveEnabled: isGlobal || !!(result.always_active_sites && result.always_active_sites[hostname])
        };

        if (config.unblockEnabled || config.alwaysActiveEnabled) {
            injectScript();
            // Dispatch event to the main world
            window.dispatchEvent(new CustomEvent('__FORCE_UNBLOCK_CONFIG__', { detail: config }));
        }
    }

    // Initial config send
    sendConfig();

    // Listen for messages from popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === "toggle") {
            sendConfig();
            // If they just enabled 'Always Active', we might need a refresh to apply it cleanly,
            // but our injected code tries to handle it. 
            // However, visibility overrides are best applied at document_start.
        }
    });

    // Also send config on ready state changes just in case
    document.addEventListener('DOMContentLoaded', sendConfig);

})();
