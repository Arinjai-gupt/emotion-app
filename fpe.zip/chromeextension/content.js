(async function() {
    const hostname = window.location.hostname;
    
    async function sendConfig() {
        const result = await chrome.storage.local.get(['enabled_sites', 'always_active_sites', 'global_mode']);
        const isGlobal = !!result.global_mode;
        
        const config = {
            unblockEnabled: isGlobal || !!(result.enabled_sites && result.enabled_sites[hostname]),
            alwaysActiveEnabled: true // Now globally forced
        };

        // Dispatch event to the main world unconditionally
        window.dispatchEvent(new CustomEvent('__FORCE_UNBLOCK_CONFIG__', { detail: config }));
    }

    // Initial config send
    sendConfig();

    // Listen for messages from popup
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === "toggle") {
            sendConfig();
            // If they just enabled 'Always Active', we might need a refresh to apply it cleanly,
            // but our injected code tries to handle it. 
            // However, visibility overrides are best applied at document_start.
        }
    });

    // Also send config on ready state changes just in case
    document.addEventListener('DOMContentLoaded', sendConfig);

})();
