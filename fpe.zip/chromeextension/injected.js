(function() {
    // Configuration - will be updated by content script
    const config = {
        unblockEnabled: true,
        alwaysActiveEnabled: false
    };

    // Listen for config updates from content script
    window.addEventListener('__FORCE_UNBLOCK_CONFIG__', (e) => {
        Object.assign(config, e.detail);
        // console.log('ForceUnblock - Config Updated:', config);
        if (config.alwaysActiveEnabled) {
            applyAlwaysActive();
        }
    });

    const BLOCKED_EVENTS = ['copy', 'paste', 'cut', 'contextmenu', 'selectstart', 'dragstart'];
    
    // Check if it's a copy/paste shortcut to protect keydown/keypress
    const isShortcut = (e) => (e.ctrlKey || e.metaKey) && ['c', 'v', 'x', 'a', 'p'].includes(e.key?.toLowerCase());

    // 1. Core Event Prototype Overrides (Unblock Feature)
    const originalPreventDefault = Event.prototype.preventDefault;
    const originalStopPropagation = Event.prototype.stopPropagation;
    const originalStopImmediatePropagation = Event.prototype.stopImmediatePropagation;

    Event.prototype.preventDefault = function() {
        if (config.unblockEnabled) {
            if (BLOCKED_EVENTS.includes(this.type)) return;
            if (this.type.startsWith('key') && isShortcut(this)) return;
        }
        return originalPreventDefault.apply(this, arguments);
    };

    Event.prototype.stopPropagation = function() {
        if (config.unblockEnabled) {
            if (BLOCKED_EVENTS.includes(this.type)) return;
            if (this.type.startsWith('key') && isShortcut(this)) return;
        }
        return originalStopPropagation.apply(this, arguments);
    };

    Event.prototype.stopImmediatePropagation = function() {
        if (config.unblockEnabled) {
            if (BLOCKED_EVENTS.includes(this.type)) return;
            if (this.type.startsWith('key') && isShortcut(this)) return;
        }
        return originalStopImmediatePropagation.apply(this, arguments);
    };

    // 2. addEventListener Override
    const originalAddEventListener = EventTarget.prototype.addEventListener;
    EventTarget.prototype.addEventListener = function(type, listener, options) {
        const blockedEvents = ['visibilitychange', 'blur', 'focus', 'mouseleave', 'mouseout', 'pointerlockchange'];
        if (config.alwaysActiveEnabled && blockedEvents.includes(type)) {
            // console.log('Blocked listener for:', type);
            return;
        }
        return originalAddEventListener.apply(this, arguments);
    };

    // 3. Visibility & Focus Spoofing (Always Active Feature)
    function applyAlwaysActive() {
        if (window.__ALWAYS_ACTIVE_APPLIED__) return;
        window.__ALWAYS_ACTIVE_APPLIED__ = true;

        // Spoof document properties
        Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
        Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
        Object.defineProperty(document, 'hasFocus', { value: () => true, configurable: true });

        // Overwrite window/document event handlers
        const noop = () => {};
        ['onblur', 'onfocus', 'onvisibilitychange', 'onmouseleave', 'onpointerlockchange'].forEach(prop => {
            Object.defineProperty(window, prop, { set: noop, get: () => noop, configurable: true });
            Object.defineProperty(document, prop, { set: noop, get: () => noop, configurable: true });
        });

        // Block exiting fullscreen
        if (document.exitFullscreen) {
            const originalExitFullscreen = document.exitFullscreen;
            document.exitFullscreen = function() { return Promise.resolve(); };
        }

        // Block pointer lock (locked mode)
        if (Element.prototype.requestPointerLock) {
            Element.prototype.requestPointerLock = function() { return Promise.resolve(); };
        }
        if (document.exitPointerLock) {
            document.exitPointerLock = function() { return Promise.resolve(); };
        }

        // Block focus/blur events from firing
        const blockEvent = (e) => {
            const blocked = ['blur', 'focus', 'visibilitychange', 'mouseleave', 'pointerlockchange'];
            if (blocked.includes(e.type)) {
                e.stopImmediatePropagation();
            }
        };
        window.addEventListener('blur', blockEvent, true);
        window.addEventListener('focus', blockEvent, true);
        window.addEventListener('visibilitychange', blockEvent, true);
        window.addEventListener('pointerlockchange', blockEvent, true);
    }

    // 4. CSS Enforcement
    const style = document.createElement('style');
    style.innerHTML = `
        * {
            user-select: text !important;
            -webkit-user-select: text !important;
            -moz-user-select: text !important;
            -ms-user-select: text !important;
        }
    `;
    document.documentElement.appendChild(style);

    // 5. MutationObserver for dynamic cleanup
    const cleanupNode = (node) => {
        if (node.nodeType !== 1) return;
        const attrs = ['oncopy', 'onpaste', 'oncut', 'oncontextmenu', 'onselectstart'];
        attrs.forEach(attr => { if (node.hasAttribute(attr)) node.removeAttribute(attr); });
        
        if (node.style && (node.style.userSelect === 'none' || node.style.webkitUserSelect === 'none')) {
            node.style.setProperty('user-select', 'text', 'important');
            node.style.setProperty('-webkit-user-select', 'text', 'important');
        }
    };

    const observer = new MutationObserver((mutations) => {
        mutations.forEach((m) => m.addedNodes.forEach(n => cleanupNode(n)));
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    cleanupNode(document.documentElement);

    // 6. Shadow DOM
    const originalAttachShadow = Element.prototype.attachShadow;
    Element.prototype.attachShadow = function() {
        const root = originalAttachShadow.apply(this, arguments);
        cleanupNode(root);
        observer.observe(root, { childList: true, subtree: true });
        return root;
    };

    // 7. KEYDOWN Fix (Shortcut Protection)
    window.addEventListener('keydown', (e) => {
        if (config.unblockEnabled && isShortcut(e)) {
            e.stopPropagation();
            e.stopImmediatePropagation();
            // We do NOT call preventDefault here, we WANT it to happen.
            // But we stop others from blocking it.
        }
    }, true);

    // 8. Block property setters for oncopy/onpaste etc
    ['oncopy', 'onpaste', 'oncut', 'oncontextmenu', 'onselectstart'].forEach(prop => {
        const noop = () => {};
        Object.defineProperty(document, prop, {
            get: () => noop,
            set: () => {}, // Ignore attempts to set it
            configurable: true
        });
        Object.defineProperty(window, prop, {
            get: () => noop,
            set: () => {},
            configurable: true
        });
    });

    console.log('ForceUnblock - Elite: Main World Injected & Ready (Aggressive Mode)');
})();
