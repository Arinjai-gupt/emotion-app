(function() {
    const config = {
        unblockEnabled: true,
        alwaysActiveEnabled: true // Force true to run on every page and tab
    };

    // Listen for config updates from content script
    window.addEventListener('__FORCE_UNBLOCK_CONFIG__', (e) => {
        // We only care about unblockEnabled since alwaysActive is forced globally
        config.unblockEnabled = e.detail.unblockEnabled;
    });

    const BLOCKED_EVENTS = ['copy', 'paste', 'cut', 'contextmenu', 'selectstart', 'dragstart'];
    
    // Check if it's a copy/paste shortcut to protect keydown/keypress
    const isShortcut = (e) => (e.ctrlKey || e.metaKey) && ['c', 'v', 'x', 'a', 'p'].includes(e.key?.toLowerCase());

    // 1. Core Event Prototype Overrides (Unblock Feature)
    const originalPreventDefault = Event.prototype.preventDefault;
    const originalStopPropagation = Event.prototype.stopPropagation;
    const originalStopImmediatePropagation = Event.prototype.stopImmediatePropagation;

    Event.prototype.preventDefault = function() {
        if (config.unblockEnabled) {
            if (BLOCKED_EVENTS.includes(this.type)) return;
            if (this.type.startsWith('key') && isShortcut(this)) return;
        }
        return originalPreventDefault.apply(this, arguments);
    };

    Event.prototype.stopPropagation = function() {
        if (config.unblockEnabled) {
            if (BLOCKED_EVENTS.includes(this.type)) return;
            if (this.type.startsWith('key') && isShortcut(this)) return;
        }
        return originalStopPropagation.apply(this, arguments);
    };

    Event.prototype.stopImmediatePropagation = function() {
        if (config.unblockEnabled) {
            if (BLOCKED_EVENTS.includes(this.type)) return;
            if (this.type.startsWith('key') && isShortcut(this)) return;
        }
        return originalStopImmediatePropagation.apply(this, arguments);
    };

    // 2. addEventListener Override
    const originalAddEventListener = EventTarget.prototype.addEventListener;
    EventTarget.prototype.addEventListener = function(type, listener, options) {
        const blockedEvents = ['visibilitychange', 'mouseleave', 'pointerlockchange'];
        if (blockedEvents.includes(type)) {
            return;
        }
        if ((type === 'blur' || type === 'focus') && (this === window || this === document)) {
            return;
        }
        return originalAddEventListener.apply(this, arguments);
    };

    // 3. Visibility & Focus Spoofing (Always Active Feature - Globally Applied)
    function applyAlwaysActive() {
        if (window.__ALWAYS_ACTIVE_APPLIED__) return;
        window.__ALWAYS_ACTIVE_APPLIED__ = true;

        // Spoof document properties safely on prototypes
        Object.defineProperty(Document.prototype, 'visibilityState', { get: () => 'visible', configurable: true });
        Object.defineProperty(Document.prototype, 'hidden', { get: () => false, configurable: true });
        Document.prototype.hasFocus = function() { return true; };

        // Overwrite window/document event handlers
        const noop = () => {};
        ['onblur', 'onfocus', 'onvisibilitychange', 'onmouseleave', 'onpointerlockchange'].forEach(prop => {
            Object.defineProperty(window, prop, { set: noop, get: () => noop, configurable: true });
            Object.defineProperty(Document.prototype, prop, { set: noop, get: () => noop, configurable: true });
        });

        // Block exiting fullscreen
        if (Document.prototype.exitFullscreen) {
            Document.prototype.exitFullscreen = function() { return Promise.resolve(); };
        }

        // Block pointer lock (locked mode)
        if (Element.prototype.requestPointerLock) {
            Element.prototype.requestPointerLock = function() { return Promise.resolve(); };
        }
        if (Document.prototype.exitPointerLock) {
            Document.prototype.exitPointerLock = function() { return Promise.resolve(); };
        }

        // Block focus/blur events from firing
        const blockEvent = (e) => {
            if (e.type === 'blur' || e.type === 'focus') {
                if (e.target !== window && e.target !== document) {
                    return; // Let elements blur/focus normally
                }
            }
            e.stopImmediatePropagation();
            e.stopPropagation();
        };
        window.addEventListener('blur', blockEvent, true);
        window.addEventListener('focus', blockEvent, true);
        window.addEventListener('visibilitychange', blockEvent, true);
        window.addEventListener('pointerlockchange', blockEvent, true);
        window.addEventListener('mouseleave', blockEvent, true);
    }
    
    // Apply immediately to work on every page and tab
    applyAlwaysActive();

    // 4. CSS Enforcement
    const style = document.createElement('style');
    style.innerHTML = `
        * {
            user-select: text !important;
            -webkit-user-select: text !important;
            -moz-user-select: text !important;
            -ms-user-select: text !important;
        }
    `;
    document.documentElement.appendChild(style);

    // 5. MutationObserver for dynamic cleanup
    const cleanupNode = (node) => {
        if (node.nodeType !== 1) return;
        const attrs = ['oncopy', 'onpaste', 'oncut', 'oncontextmenu', 'onselectstart'];
        attrs.forEach(attr => { if (node.hasAttribute(attr)) node.removeAttribute(attr); });
        
        if (node.style && (node.style.userSelect === 'none' || node.style.webkitUserSelect === 'none')) {
            node.style.setProperty('user-select', 'text', 'important');
            node.style.setProperty('-webkit-user-select', 'text', 'important');
        }
    };

    const observer = new MutationObserver((mutations) => {
        mutations.forEach((m) => m.addedNodes.forEach(n => cleanupNode(n)));
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
    cleanupNode(document.documentElement);

    // 6. Shadow DOM
    const originalAttachShadow = Element.prototype.attachShadow;
    Element.prototype.attachShadow = function() {
        const root = originalAttachShadow.apply(this, arguments);
        cleanupNode(root);
        observer.observe(root, { childList: true, subtree: true });
        return root;
    };

    // 7. KEYDOWN Fix (Shortcut Protection)
    window.addEventListener('keydown', (e) => {
        if (config.unblockEnabled && isShortcut(e)) {
            e.stopPropagation();
            e.stopImmediatePropagation();
            // We do NOT call preventDefault here, we WANT it to happen.
            // But we stop others from blocking it.
        }
    }, true);

    // 8. Block property setters for oncopy/onpaste etc
    ['oncopy', 'onpaste', 'oncut', 'oncontextmenu', 'onselectstart'].forEach(prop => {
        const noop = () => {};
        Object.defineProperty(document, prop, {
            get: () => noop,
            set: () => {}, // Ignore attempts to set it
            configurable: true
        });
        Object.defineProperty(window, prop, {
            get: () => noop,
            set: () => {},
            configurable: true
        });
    });

    console.log('ForceUnblock - Elite: Main World Injected & Ready (Aggressive Mode)');
})();
