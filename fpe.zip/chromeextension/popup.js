document.addEventListener('DOMContentLoaded', async () => {
    const unblockToggle = document.getElementById('unblock-toggle');
    const activeToggle = document.getElementById('active-toggle');
    const globalToggle = document.getElementById('global-toggle');
    const statusText = document.getElementById('status-text');
    const statusChip = document.getElementById('status-chip');
    const hostnameEl = document.getElementById('hostname');

    // 1. Get current tab info
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab) return;
    
    let url;
    try {
        url = new URL(tab.url);
    } catch (e) {
        hostnameEl.textContent = "unsupported page";
        unblockToggle.disabled = true;
        activeToggle.disabled = true;
        return;
    }
    
    const hostname = url.hostname;
    hostnameEl.textContent = hostname;

    // 2. Load current states
    const result = await chrome.storage.local.get(['enabled_sites', 'always_active_sites', 'global_mode']);
    const enabledSites = result.enabled_sites || {};
    const alwaysActiveSites = result.always_active_sites || {};
    const isGlobalMode = !!result.global_mode;

    const isUnblockEnabled = !!enabledSites[hostname];
    const isAlwaysActiveEnabled = !!alwaysActiveSites[hostname];

    // 3. Update UI
    globalToggle.checked = isGlobalMode;
    unblockToggle.checked = isUnblockEnabled;
    activeToggle.checked = isAlwaysActiveEnabled;
    
    if (isGlobalMode) {
        unblockToggle.parentElement.parentElement.classList.add('disabled-by-global');
        activeToggle.parentElement.parentElement.classList.add('disabled-by-global');
    }
    
    updateStatusUI();

    // 4. Handle Unblock toggle change
    unblockToggle.addEventListener('change', async () => {
        const enabled = unblockToggle.checked;
        const data = await chrome.storage.local.get(['enabled_sites']);
        const sites = data.enabled_sites || {};
        
        if (enabled) sites[hostname] = true;
        else delete sites[hostname];

        await chrome.storage.local.set({ enabled_sites: sites });
        notifyContentScript();
        updateStatusUI();
    });

    // 5. Handle Always Active toggle change
    activeToggle.addEventListener('change', async () => {
        const enabled = activeToggle.checked;
        const data = await chrome.storage.local.get(['always_active_sites']);
        const sites = data.always_active_sites || {};
        
        if (enabled) sites[hostname] = true;
        else delete sites[hostname];

        await chrome.storage.local.set({ always_active_sites: sites });
        notifyContentScript();
        updateStatusUI();
    });

    // 6. Handle Global toggle change
    globalToggle.addEventListener('change', async () => {
        const enabled = globalToggle.checked;
        await chrome.storage.local.set({ global_mode: enabled });
        
        if (enabled) {
            unblockToggle.parentElement.parentElement.classList.add('disabled-by-global');
            activeToggle.parentElement.parentElement.classList.add('disabled-by-global');
        } else {
            unblockToggle.parentElement.parentElement.classList.remove('disabled-by-global');
            activeToggle.parentElement.parentElement.classList.remove('disabled-by-global');
        }

        notifyAllTabs();
        updateStatusUI();
    });

    function updateStatusUI() {
        const isGlobal = globalToggle.checked;
        const active = isGlobal || unblockToggle.checked || activeToggle.checked;
        
        if (isGlobal) {
            statusText.textContent = "Antivirus is ON";
            statusChip.className = "status-on global-active";
        } else if (active) {
            statusText.textContent = "SYSTEM ACTIVE";
            statusChip.className = "status-on";
        } else {
            statusText.textContent = "Antivirus is off";
            statusChip.className = "status-off";
        }
    }

    function notifyContentScript() {
        chrome.tabs.sendMessage(tab.id, { action: "toggle" }).catch(() => {
            // Content script might not be injected yet
        });
    }

    async function notifyAllTabs() {
        const tabs = await chrome.tabs.query({});
        tabs.forEach(t => {
            chrome.tabs.sendMessage(t.id, { action: "toggle" }).catch(() => {});
        });
    }
});
